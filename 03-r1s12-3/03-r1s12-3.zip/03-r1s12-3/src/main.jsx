import React from "react";
import ReactDOM from "react-dom/client";
import UserSelect from "./App.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
    <React.StrictMode>
        {/* <App /> */}
        <UserSelect />
    </React.StrictMode>
);
